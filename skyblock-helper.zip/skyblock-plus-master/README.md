# Skyblock Plus Discord Bot
<a href="https://github.com/kr45732/skyblock-plus/blob/master/LICENSE" target="_blank">
  <img alt="license" src="https://img.shields.io/github/license/kr45732/skyblock-plus?style=for-the-badge" />
</a>
<a href="https://sbplus.codes/support" target="_blank">
  <img alt="license" src="https://img.shields.io/discord/796790757947867156?color=4166f5&label=discord&style=for-the-badge" />
</a> 
<a href="https://github.com/kr45732/skyblock-plus/stargazers" target="_blank">
  <img alt="license" src="https://img.shields.io/github/stars/kr45732/skyblock-plus?style=for-the-badge" />
</a>
<a href="https://github.com/kr45732/skyblock-plus/contributors" target="_blank">
  <img alt="license" src="https://img.shields.io/github/contributors/kr45732/skyblock-plus?style=for-the-badge" />
</a>

This is the source code for the Skyblock Plus Discord bot. A full list of commands and features as well as additional information can be found on the website linked below.

## Bug reports
Feel free to make an issue or report the bug using the support server linked below.

## Contributing
Contributions are greatly appreciated. Feel free to make a pull request!

## Contact
You can contact me through the Discord server linked below.

## Useful links
- Website: https://sbplus.codes
- Invite: https://sbplus.codes/invite
- Support: https://sbplus.codes/support
